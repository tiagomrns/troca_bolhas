// Trabalho Final de Programacao           Docente: Bertinho D'Andrade Costa
//   Roberta Vieira 89711      Tiago Martins 89718

#include "all.h"

void HelpPROMT();
void ARG_GET(int argc, char const *argv[], BASE *x);
void ARG_SET(char const *str, char const *argv[], int i, int *z);
void limites_tamanho_janela(BASE *b);
int DEFAULTS(BASE *b);
