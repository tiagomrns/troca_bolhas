// Trabalho Final de Programacao           Docente: Bertinho D'Andrade Costa
//   Roberta Vieira 89711      Tiago Martins 89718

#include "all.h"

void faz_tudo_resultados(RESULTADO **ptop, int score);
void guarda_fich(RESULTADO **ptop);
void troca_blocos(RESULTADO **b1, RESULTADO **b2);
void ordenar_pontuacoes(RESULTADO **ptop);
void faz_resultados_txt(RESULTADO *top);
