// Trabalho Final de Programacao           Docente: Bertinho D'Andrade Costa
//   Roberta Vieira 89711      Tiago Martins 89718

#include "all.h"

void Inicializar(BASE **b, int argc, char const *argv[]);

void Troca(BASE *b);
void Gravidade(BASE *b);

void NovaJogada(BASE *b);
void UI(BASE *b);
void Destroi_e_Cai(BASE *b);
void endGameCONDITION(BASE *b);

void NovoJogo(BASE *b);
void JOGAR(BASE *b);
void LimpaJogo(BASE *b);
