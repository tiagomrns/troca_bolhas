// Trabalho Final de Programacao           Docente: Bertinho D'Andrade Costa
//   Roberta Vieira 89711      Tiago Martins 89718

#include "all.h"

void DESTRUICAO(BASE *b);
int Match(BASE *b, BOLHA b1, BOLHA b2);
int LC(BOLHA *a, char c, BASE *b);
void marca_para_destruicao(BASE *b, BOLHA *a);
