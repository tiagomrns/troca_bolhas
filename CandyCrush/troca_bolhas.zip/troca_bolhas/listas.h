// Trabalho Final de Programacao           Docente: Bertinho D'Andrade Costa
//   Roberta Vieira 89711      Tiago Martins 89718

#include "all.h"

void IniciaLista(BASE *b);
BOLHA *AddFinalLista(BOLHA ***pind);
void rmLista(BASE *b, BOLHA **ind);//BASE *b, BOLHA *a);
BOLHA *Sherlock(BASE *b, BOLHA *a);
void TrocarBLOCOS(BASE *b, BOLHA *j, BOLHA *k);
